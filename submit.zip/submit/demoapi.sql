

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `department`
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `ID` bigint(20) unsigned NOT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `OPENPOSITION` int(11) DEFAULT NULL,
  `MANAGERID` bigint(20) DEFAULT NULL, -- the manager id of department
  `PARENTID` bigint(20) DEFAULT NULL,-- parent department id
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO department VALUES ('1', 'finance', 'chengdu', '10', '1', null);
INSERT INTO department VALUES ('2', 'tech', 'shenzheng', '20', '2', '1');
INSERT INTO department VALUES ('3', 'assistance', 'chengdu', '30', '3', null);

-- ----------------------------
-- Table structure for `employee`
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `ID` bigint(20) unsigned NOT NULL,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  `IDAPUSERNAME` varchar(255) DEFAULT NULL,
  `GENDERID` int DEFAULT NULL,
  `BIRTHDAY` datetime DEFAULT NULL,
  `TITLE` varchar(255) DEFAULT NULL,
  `GRADE` varchar(10) DEFAULT NULL,
  `PARENTID` bigint(20) DEFAULT NULL, -- manager id of employee
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO employee VALUES ('1', 'Test1', 'T', 'Test', '0', null, 'ff', '1', '1');
INSERT INTO employee VALUES ('2', 'Test2', '4', '5', '1', null, 'hh', '2', '1');
INSERT INTO employee VALUES ('3', 'Test3', 'w', 'w', '0', null, 'kk', '3', '1');


