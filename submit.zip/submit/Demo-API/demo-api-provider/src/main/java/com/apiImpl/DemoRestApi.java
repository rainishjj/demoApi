package com.apiImpl;

import com.api.DemoApi;
import com.model.BaseResult;
import com.model.Department;
import com.model.Employee;
import com.service.DemoService;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Administrator on 2017-05-13.
 */
@Path("/demo")
@Component("demoRestApi")
public class DemoRestApi implements DemoApi {
    @Autowired
    @Qualifier("demoServiceImpl")
    private DemoService demoService;

    /**
     * retrieve all departmetns
     * @return
     */
    @POST
    @Path("/getAllDepartments")
    @Produces({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Consumes({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    public BaseResult<List<Department>> getAllDepartments() {
        List<Department> departments = new ArrayList<>();
        BaseResult<List<Department>> result = new BaseResult<List<Department>>();
        departments = demoService.selectAllDepartments();

        if(departments!=null&&departments.size()>0){// 查出数据
            result.setSucc(true);
            result.setData(departments);
            result.setTotal(departments.size());
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    /**
     * retrieve department by id
     * @param dept
     * @return
     */
    @POST
    @Path("/getDepartmentById")
    @Produces({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Consumes({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Override
    public BaseResult<Department> getDepartmentById(Department dept) {
        BaseResult<Department> result = new BaseResult<Department>();
        dept = demoService.selectDepartmentById(dept.getId());
        if(dept!=null){// 查出数据
            result.setSucc(true);
            result.setData(dept);
            result.setTotal(1);
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @POST
    @Path("/getSubDepartmentById")
    @Produces({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Consumes({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Override
    public BaseResult<List<Department>> getSubDepartmentById(Department dept) {
        BaseResult<List<Department>> result = new BaseResult<List<Department>>();
        List<Department> depts = demoService.selectSubDepartmentById(dept.getId());
        if(depts!=null){// 查出数据
            result.setSucc(true);
            result.setData(depts);
            result.setTotal(1);
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @POST
    @Path("/getEmployeeByDeptId")
    @Produces({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Consumes({MediaType.APPLICATION_JSON + ";charset=UTF-8"})
    @Override
    public BaseResult<List<Employee>> getEmployeeByDeptId(Department dept) {
        BaseResult<List<Employee>> result = new BaseResult<List<Employee>>();
        List<Employee> employees = demoService.selectEmployeeByDeptId(dept.getId());
        if(employees!=null && employees.size()>0){// 查出数据
            result.setSucc(true);
            result.setData(employees);
            result.setTotal(1);
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @Override
    public BaseResult<Boolean> modifyDepartment(Department dept) {
        BaseResult<Boolean> result = new BaseResult<Boolean>();
        Boolean succ = demoService.updateDepartment(dept.getId());
        result.setSucc(succ);
        return result;
    }

    @Override
    public BaseResult<Boolean> deleteDepartment(Department dept) {
        BaseResult<Boolean> result = new BaseResult<Boolean>();
        Boolean succ = demoService.deleteDepartment(dept.getId());
        result.setSucc(succ);
        return result;
    }

    @Override
    public BaseResult<List<Employee>> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        BaseResult<List<Employee>> result = new BaseResult<List<Employee>>();
        employees = demoService.selectAllEmployees();

        if(employees!=null&&employees.size()>0){// 查出数据
            result.setSucc(true);
            result.setData(employees);
            result.setTotal(employees.size());
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @Override
    public BaseResult<Employee> getEmployeeById(Employee employee) {
        BaseResult<Employee> result = new BaseResult<Employee>();
        employee = demoService.selectEmployeeById(employee.getId());
        if(employee!=null){// 查出数据
            result.setSucc(true);
            result.setData(employee);
            result.setTotal(1);
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @Override
    public BaseResult<Department> getDeptByEmployeeId(Employee employee) {
        BaseResult<Department> result = new BaseResult<Department>();
        Department department = new Department();
        department = demoService.selectDeptByEmployeeId(employee.getId());
        if(department!=null){// 查出数据
            result.setSucc(true);
            result.setData(department);
            result.setTotal(1);
        }else {// 未查出数据
            result.setSucc(false);
            result.setErrMsg("Data Not Found");
        }
        return result;
    }

    @Override
    public BaseResult<Boolean> modifyEmployee(Employee employee) {
        return null;
    }

    @Override
    public BaseResult<Boolean> deleteEmployee(Employee employee) {
        return null;
    }

    @Override
    public BaseResult<Boolean> addSubDept(Department dept) {
        return null;
    }

    @Override
    public BaseResult<Boolean> addEmployee(Department dept) {
        return null;
    }


}
