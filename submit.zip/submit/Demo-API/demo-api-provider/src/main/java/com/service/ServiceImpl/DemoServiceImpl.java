package com.service.ServiceImpl;


import com.dao.DemoMapper;
import com.model.Department;
import com.model.Employee;
import com.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017-05-13.
 */
@Service("demoServiceImpl")
public class DemoServiceImpl implements DemoService {

    @Autowired
    private DemoMapper mapper;

    @Override
    public List<Department> selectAllDepartments() {
        return mapper.selectAllDepartments();
    }

    @Override
    public Department selectDepartmentById(long id) {
        return mapper.selectDepartmentById(id);
    }

    @Override
    public List<Department> selectSubDepartmentById(long id) {
        return mapper.selectSubDepartmentById(id);
    }

    @Override
    public List<Employee> selectEmployeeByDeptId(long id) {
        return mapper.selectEmployeeByDeptId(id);
    }

    @Override
    public Boolean updateDepartment(long id) {
        return mapper.updateDepartment(id);
    }

    @Override
    public Boolean deleteDepartment(long id) {
        return mapper.deleteDepartment(id);
    }

    @Override
    public List<Employee> selectAllEmployees() {
        return mapper.selectAllEmployees();
    }

    @Override
    public Employee selectEmployeeById(long id) {
        return mapper.selectEmployeeById(id);
    }

    @Override
    public Department selectDeptByEmployeeId(long id) {
        return mapper.selectDeptByEmployeeId(id);
    }

    @Override
    public Boolean updateEmployee(long id) {
        return null;
    }

    @Override
    public Boolean deleteEmployee(long id) {
        return null;
    }

    @Override
    public Boolean insertSubDept(Department dept) {
        return null;
    }

    @Override
    public Boolean insertEmployee(Department dept) {
        return null;
    }
}
