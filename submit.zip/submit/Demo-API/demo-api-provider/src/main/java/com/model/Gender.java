package com.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017-05-13.
 */
public enum Gender {
    MALE(0, "male"),FEMAIL(1, "femail");

    private Gender(int status, String description) {
        this.status = status;
        this.description = description;
    }

    /** 状态值 */
    private int status;

    /** 状态描述 */
    private String description;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 根据状态值获取枚举值
     *
     * @param status
     * @return
     */
    public static Gender getStatus(int status) {
        for (Gender e : Gender.values()) {
            if (e.getStatus() == status) {
                return e;
            }
        }
        return null;
    }

    /**
     * 返回key value集合
     *
     * @return
     */
    public static Map<Integer, String> getStatusMap() {
        Map<Integer, String> rs = new HashMap<Integer, String>();
        for (Gender o : Gender.values()) {
            if (o.getStatus() > -1)
                rs.put(o.getStatus(), o.getDescription());
        }

        return rs;
    }
}
