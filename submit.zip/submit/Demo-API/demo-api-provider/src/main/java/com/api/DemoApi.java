package com.api;

import com.model.BaseResult;
import com.model.Department;
import com.model.Employee;

import java.util.List;

/**
 * Created by Administrator on 2017-05-13.
 */
public interface DemoApi {
    /**
     * retrieve all department
     * @return
     */
    public BaseResult<List<Department>> getAllDepartments();

    /**
     * retrieve department by id
     * @param dept
     * @return
     */
    public BaseResult<Department> getDepartmentById(Department dept);

    /**
     * retrieve sub-department by this department id
     * @param dept
     * @return
     */
    public BaseResult<List<Department>> getSubDepartmentById(Department dept);

    /**
     * Retrieve all the employees that belong to this department
     * @param dept
     * @return
     */
    public BaseResult<List<Employee>> getEmployeeByDeptId(Department dept);

    /**
     * Update this department
     * @param dept
     * @return
     */
    public BaseResult<Boolean> modifyDepartment(Department dept);

    /**
     * Remove this department
     * @param dept
     * @return
     */
    public BaseResult<Boolean> deleteDepartment(Department dept);

    /**
     * Retrieve all the employees
     * @return
     */
    public BaseResult<List<Employee>> getAllEmployees();

    /**
     * Retrieve one employee by employeeId
     * @param employee
     * @return
     */
    public BaseResult<Employee> getEmployeeById(Employee employee);

    /**
     * Retrieve the department of this employee
     * @param employee
     * @return
     */
    public BaseResult<Department> getDeptByEmployeeId(Employee employee);

    /**
     * Update this employee
     * @param employee
     * @return
     */
    public BaseResult<Boolean> modifyEmployee(Employee employee);

    /**
     * Remove this employee
     * @param employee
     * @return
     */
    public BaseResult<Boolean> deleteEmployee(Employee employee);

    /**
     * Create a new department as a sub-department of a given department
     * @param dept
     * @return
     */
    public BaseResult<Boolean> addSubDept(Department dept);

    /**
     * Create a new employee in a given department
     * @param dept
     * @return
     */
    public BaseResult<Boolean> addEmployee(Department dept);
}
