package com.dao;

import com.model.Department;
import com.model.Employee;

import java.util.List;

/**
 * Created by Administrator on 2017-05-13.
 */
public interface DemoMapper {
    public List<Department> selectAllDepartments();
    /**
     * retrieve department by id
     * @param id
     * @return
     */
    public Department selectDepartmentById(long id);

    /**
     * retrieve sub-department by this department id
     * @param id
     * @return
     */
    public List<Department> selectSubDepartmentById(long id);

    /**
     * Retrieve all the employees that belong to this department
     * @param id
     * @return
     */
    public List<Employee> selectEmployeeByDeptId(long id);

    /**
     * Update this department
     * @param id
     * @return
     */
    public Boolean updateDepartment(long id);

    /**
     * Remove this department
     * @param id
     * @return
     */
    public Boolean deleteDepartment(long id);

    /**
     * Retrieve all the employees
     * @return
     */
    public List<Employee> selectAllEmployees();

    /**
     * Retrieve one employee by employeeId
     * @param id
     * @return
     */
    public Employee selectEmployeeById(long id);

    /**
     * Retrieve the department of this employee
     * @param id
     * @return
     */
    public Department selectDeptByEmployeeId(long id);

    /**
     * Update this employee
     * @param id
     * @return
     */
    public Boolean updateEmployee(long id);

    /**
     * Remove this employee
     * @param id
     * @return
     */
    public Boolean deleteEmployee(long id);

    /**
     * Create a new department as a sub-department of a given department
     * @param dept
     * @return
     */
    public Boolean insertSubDept(Department dept);

    /**
     * Create a new employee in a given department
     * @param dept
     * @return
     */
    public Boolean insertEmployee(Department dept);
}
