import com.api.DemoApi;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017-05-13.
 */
public class DemoApiTest {
    @Autowired
    private DemoApi api;

    @Test
    public void getAllDepartmentTest() throws Exception {

        Map<String, String> headers = new LinkedHashMap<String, String>();
        headers.put("token","");
        Map<String,Object> params = new LinkedHashMap<>();

        Map<String, Object> result = UrlClient.postJson("http://127.0.0.1:8080/demo/getAllDepartments",params,headers);
        System.out.println(result);
    }

    @Test
    public void getDepartmentByIdTest() throws Exception {

        Map<String, String> headers = new LinkedHashMap<String, String>();
        headers.put("token","");
        Map<String,Object> params = new LinkedHashMap<>();
        params.put("id",1l);

        Map<String, Object> result = UrlClient.postJson("http://127.0.0.1:8080/demo/getDepartmentById",params,headers);
        System.out.println(result);
    }
}
