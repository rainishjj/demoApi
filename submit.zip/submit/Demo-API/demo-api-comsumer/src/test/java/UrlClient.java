import com.alibaba.fastjson.JSON;
import okhttp3.*;
import org.springframework.http.HttpMethod;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 2017/2/16.
 */
@SuppressWarnings("Duplicates")
public class UrlClient {

    final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    };

    static TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[] {};
        }

        public void checkClientTrusted(X509Certificate[] chain, String authType)  {

        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) {

        }
    } };

    public static Map<String, String> post(String serverUri,Map<String,String> params,Map<String,String> headers) throws Exception {


        StringBuilder postStr = new StringBuilder();
        for (String key:params.keySet()) {
            if ( postStr.length() != 0 )
                postStr.append('&');

            postStr.append(URLEncoder.encode(key,"UTF-8"));
            postStr.append('=');
            postStr.append(URLEncoder.encode(String.valueOf(params.get(key)), "UTF-8"));
        }

        byte[] postStrBytes = postStr.toString().getBytes("UTF-8");

        URL url = new URL(serverUri);

        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAllCerts, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        connection.setHostnameVerifier(DO_NOT_VERIFY);
        connection.setRequestMethod(HttpMethod.POST.toString());
        connection.setDoInput(true);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        connection.setRequestProperty("Content-Length", String.valueOf(postStrBytes.length));

        if(headers!=null){
            for (String key : headers.keySet()) {
                connection.setRequestProperty(key,headers.get(key));
            }
        }

        connection.getOutputStream().write(postStrBytes);

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ( (inputLine = in.readLine()) != null ) {
            response.append(inputLine);
        }
        in.close();
        System.out.println(response.toString());

        return JSON.parseObject(response.toString(), Map.class);
    }

    public static Map<String, Object> postJson(String serverUri,Map<String,Object> params,Map<String,String> headers) throws Exception {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), JSON.toJSONString(params));
        Request request = new Request.Builder()
                .url(serverUri)
                .addHeader("token",headers.get("token"))
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            String string = response.body().string();
            return JSON.parseObject(string, HashMap.class);
        } else {
            throw new IOException("Unexpected code " + response);
        }
    }

    public static Map<String, Object> getJson(String serverUri, Map<String, String> headers) throws Exception {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(serverUri)
                .addHeader("token",headers.get("token"))
                .get()
                .build();
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            String string = response.body().string();
            return JSON.parseObject(string, HashMap.class);
        } else {
            throw new IOException("Unexpected code " + response);
        }
    }

    public static Map<String, Object> get(String serverUri,Map<String,Object> params,Map<String,String> headers) throws Exception {
        StringBuilder getStr = new StringBuilder();
        if(params!=null) {
            for (String key : params.keySet()) {
                if (getStr.length() != 0)
                    getStr.append('&');

                getStr.append(URLEncoder.encode(key, "UTF-8"));
                getStr.append('=');
                getStr.append(URLEncoder.encode(String.valueOf(params.get(key)), "UTF-8"));
            }
        }
        if(getStr.length()>0) {
            serverUri=String.format("%s?%s",serverUri,getStr.toString());
        }

        URL url = new URL(serverUri);

        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAllCerts, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        connection.setHostnameVerifier(DO_NOT_VERIFY);
        connection.setRequestMethod(HttpMethod.GET.toString());
        connection.setDoInput(true);
        connection.setDoOutput(true);

        if(headers!=null){
            for (String key : headers.keySet()) {
                connection.setRequestProperty(key,headers.get(key));
            }
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ( (inputLine = in.readLine()) != null ) {
            response.append(inputLine);
        }
        in.close();
        System.out.println(response.toString());

        return JSON.parseObject(response.toString(), Map.class);
    }



    public static void init(){
        try {
            X509TrustManager xtm = new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            };
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{xtm}, new SecureRandom());
            SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .sslSocketFactory(sslSocketFactory, xtm)
                    .hostnameVerifier(new HostnameVerifier(){
                        @Override
                        public boolean verify(String s, SSLSession sslSession) {
                            return true;
                        }
                    })
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
